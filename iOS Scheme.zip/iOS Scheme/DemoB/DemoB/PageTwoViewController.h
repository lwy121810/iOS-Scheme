//
//  PageTwoViewController.h
//  DemoB
//
//  Created by yons on 17/2/20.
//  Copyright © 2017年 yons. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageTwoViewController : UIViewController
@property (nonatomic , copy) NSString *urlString;

@end
